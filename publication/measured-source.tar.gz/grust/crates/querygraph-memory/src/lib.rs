//! # querygraph-memory
//!
//! Marciana's Grust adapter: [`typesec-memory`](typesec_memory)'s `MemoryStore`
//! implemented over a compatible Grust [`GraphMutationStore`]. Records and
//! their entity knowledge graph are written *incrementally* as nodes and
//! edges. The v1 durable production path is [`TursoMemoryStore`], while the
//! generic adapter remains useful for reference and explicitly integrated
//! backends.
//!
//! ## Graph shape
//!
//! ```text
//! (:MemoryRecord {record: <json>})-[:MENTIONS]->(:MemoryEntity {name, kind})
//! (:MemoryEntity)-[:RELATES]->(:MemoryRelation {rel, fact_id})-[:RELATES]->(:MemoryEntity)
//! ```
//!
//! The full [`StoredRecord`] rides in one JSON property. Space scoping is
//! pushed into the backend; the remaining dimensions use the shared
//! [`StoreQuery::matches`] semantics. Fuller GQL pushdown is a post-v1
//! optimization: correctness is pinned by the conformance suite today.
//!
//! ## The sync/async bridge
//!
//! `MemoryStore` is synchronous by design (FABLE-MEMORY-1 §5.1); Grust's
//! `GraphStore` is async. This crate owns the one sanctioned bridge: a
//! dedicated current-thread runtime, driven directly when no runtime is on
//! the calling thread and from a scoped thread when one is (so calling the
//! vault from inside tokio — e.g. an MCP server — cannot panic).
//!
//! ## Security posture
//!
//! The store adapter round-trips [`StoredRecord`] as an opaque value; it does
//! not inspect protected content to make authorization decisions. Cognition
//! receives only the transient [`typesec_memory::AuthorizedCognitionInput`]
//! that the capability-gated vault already released, and it returns inert
//! proposals to that vault. Passing `typesec_memory::conformance` is the
//! storage compatibility bar.

use std::collections::{BTreeMap, BTreeSet};
use std::future::Future;

use chrono::{DateTime, Utc};
use grust_core::prelude::{
    Direction, Edge, EdgeQuery, GraphMutation, GraphMutationStore, Node, NodeId, Start, Step,
    Traversal, Value,
};
use sha2::{Digest, Sha256};
use typesec_memory::{MemoryId, MemoryStore, StoreBatchOp, StoreError, StoreQuery, StoredRecord};

const RECORD_LABEL: &str = "MemoryRecord";
const ENTITY_LABEL: &str = "MemoryEntity";
const RELATION_LABEL: &str = "MemoryRelation";
const MENTIONS: &str = "MENTIONS";
const RELATES: &str = "RELATES";

/// `typesec-memory`'s `MemoryStore` over any Grust [`GraphMutationStore`].
pub struct GraphStoreMemoryStore<G: GraphMutationStore> {
    graph: G,
    bridge: Bridge,
}

impl<G: GraphMutationStore> GraphStoreMemoryStore<G> {
    /// Wrap a Grust backend.
    pub fn new(graph: G) -> Self {
        Self {
            graph,
            bridge: Bridge::new(),
        }
    }

    /// Borrow the underlying Grust store.
    pub fn graph(&self) -> &G {
        &self.graph
    }

    fn run<T: Send>(
        &self,
        fut: impl Future<Output = grust_core::prelude::Result<T>> + Send,
    ) -> Result<T, StoreError> {
        self.bridge
            .run(fut)
            .map_err(|err| StoreError::Backend(err.to_string()))
    }

    fn fetch(&self, id: &MemoryId) -> Result<Option<StoredRecord>, StoreError> {
        let node = self.run(self.graph.get_node(&record_node_id(id)))?;
        node.map(|node| decode_record(&node)).transpose()
    }

    /// Reachable entity node ids within `hops` logical RELATES steps.
    ///
    /// Current relationships use an assertion node so identical endpoint pairs
    /// can retain independent fact lineage. The one-edge traversal remains for
    /// durable stores written by the pre-0.13 representation.
    fn reachable_entities(&self, entity: &str, hops: u8) -> Result<Vec<NodeId>, StoreError> {
        let start = entity_node_id(entity);
        let mut ordered = vec![start.clone()];
        let mut seen = BTreeSet::from([start.clone()]);
        let mut frontier = vec![start];

        // Expand one *logical* relationship hop at a time. Running an all-old
        // path and an all-new path from the origin misses durable graphs whose
        // migration boundary falls in the middle of the requested radius.
        for _ in 0..hops {
            let mut next = BTreeSet::new();
            for current in frontier {
                let traversals = [
                    vec![Step {
                        direction: Direction::Both,
                        edge: Some(RELATES.into()),
                        node: Some(ENTITY_LABEL.into()),
                    }],
                    vec![
                        Step {
                            direction: Direction::Both,
                            edge: Some(RELATES.into()),
                            node: Some(RELATION_LABEL.into()),
                        },
                        Step {
                            direction: Direction::Both,
                            edge: Some(RELATES.into()),
                            node: Some(ENTITY_LABEL.into()),
                        },
                    ],
                ];
                for steps in traversals {
                    let traversal = Traversal {
                        start: Start::Node(current.clone()),
                        steps,
                        limit: None,
                    };
                    for node in self.run(self.graph.traverse(traversal))? {
                        if !seen.contains(&node.id) {
                            next.insert(node.id);
                        }
                    }
                }
            }
            if next.is_empty() {
                break;
            }
            for id in &next {
                seen.insert(id.clone());
                ordered.push(id.clone());
            }
            frontier = next.into_iter().collect();
        }
        Ok(ordered)
    }

    /// The graph mutations that persist one record: the record node plus its
    /// entity nodes and MENTIONS edges. Shared by `put` and `apply_batch`.
    fn record_mutations(record: &StoredRecord) -> Result<Vec<GraphMutation>, StoreError> {
        let mut muts = vec![GraphMutation::UpsertNode(encode_record(record)?)];
        for entity in &record.entities {
            let mut props: BTreeMap<String, Value> = BTreeMap::new();
            props.insert("name".into(), Value::String(entity.name.clone()));
            props.insert("kind".into(), Value::String(entity.kind.clone()));
            muts.push(GraphMutation::UpsertNode(Node::new(
                ENTITY_LABEL,
                entity_node_id(&entity.name),
                props,
            )));
            muts.push(GraphMutation::UpsertEdge(Edge::new(
                MENTIONS,
                record_node_id(&record.id),
                entity_node_id(&entity.name),
                BTreeMap::new(),
            )));
        }
        Ok(muts)
    }
}

impl<G: GraphMutationStore> MemoryStore for GraphStoreMemoryStore<G> {
    fn put(&self, record: StoredRecord) -> Result<(), StoreError> {
        let muts = Self::record_mutations(&record)?;
        self.run(self.graph.apply_mutations(&muts))
    }

    fn get(&self, id: &MemoryId) -> Result<Option<StoredRecord>, StoreError> {
        self.fetch(id)
    }

    /// Apply the whole batch as one `apply_mutations` call — atomic on any
    /// backend whose `GraphMutationStore` overrides it transactionally (the
    /// consolidation path relies on this so a supersede never half-commits).
    /// An `Invalidate` reads the record, stamps `invalid_at`, and re-upserts
    /// it; that read is outside the mutation set, but the capability that
    /// authorized the consolidation is the logical lock.
    fn apply_batch(&self, ops: Vec<StoreBatchOp>) -> Result<(), StoreError> {
        let mut muts: Vec<GraphMutation> = Vec::new();
        for op in ops {
            match op {
                StoreBatchOp::Put(record) => muts.extend(Self::record_mutations(&record)?),
                StoreBatchOp::Invalidate { id, at } => {
                    let mut record = self
                        .fetch(&id)?
                        .ok_or_else(|| StoreError::Backend(format!("no record {id}")))?;
                    record.invalid_at = Some(at);
                    muts.push(GraphMutation::UpsertNode(encode_record(&record)?));
                }
            }
        }
        self.run(self.graph.apply_mutations(&muts))
    }

    fn query(&self, query: &StoreQuery) -> Result<Vec<StoredRecord>, StoreError> {
        // Pushdown: the space filter travels to the backend as a property
        // predicate (record nodes carry `space` as a plain prop), so a
        // space-scoped query never scans other tenants' records. Remaining
        // dimensions filter through the shared `StoreQuery::matches`
        // semantics the conformance suite pins.
        let start = match &query.space_id {
            Some(space) => Start::NodesByProperty {
                label: RECORD_LABEL.into(),
                key: "space".into(),
                value: Value::String(space.clone()),
            },
            None => Start::NodesByLabel(RECORD_LABEL.into()),
        };
        let nodes = self.run(self.graph.traverse(Traversal {
            start,
            steps: Vec::new(),
            limit: None,
        }))?;
        let mut out = Vec::new();
        for node in nodes {
            let record = decode_record(&node)?;
            if query.matches(&record) {
                out.push(record);
            }
        }
        // Same deterministic order as the reference stores.
        out.sort_by(|a, b| b.observed_at.cmp(&a.observed_at).then(b.id.cmp(&a.id)));
        if let Some(limit) = query.limit {
            out.truncate(limit);
        }
        Ok(out)
    }

    fn invalidate(&self, id: &MemoryId, at: DateTime<Utc>) -> Result<(), StoreError> {
        let mut record = self
            .fetch(id)?
            .ok_or_else(|| StoreError::Backend(format!("no record {id}")))?;
        record.invalid_at = Some(at);
        self.run(self.graph.put_node(&encode_record(&record)?))?;
        Ok(())
    }

    fn tombstone(&self, id: &MemoryId) -> Result<bool, StoreError> {
        let existed = self.fetch(id)?.is_some();
        if !existed {
            return Ok(false);
        }
        // Discover current assertion nodes and legacy direct facts, then delete
        // that set with the record in one mutation batch. Transactional stores
        // can roll the deletion batch back, but discovery precedes it; callers
        // must synchronize concurrent link and tombstone operations.
        let assertions = self.run(self.graph.traverse(Traversal {
            start: Start::NodesByProperty {
                label: RELATION_LABEL.into(),
                key: "fact_id".into(),
                value: Value::String(id.as_str().to_string()),
            },
            steps: Vec::new(),
            limit: None,
        }))?;
        let relates = self.run(self.graph.get_edges(EdgeQuery {
            from: None,
            to: None,
            label: Some(RELATES.into()),
        }))?;
        let fact_id = Value::String(id.as_str().to_string());
        let mut mutations = vec![GraphMutation::DeleteNode(record_node_id(id))];
        mutations.extend(
            assertions
                .into_iter()
                .map(|assertion| GraphMutation::DeleteNode(assertion.id)),
        );
        mutations.extend(
            relates
                .into_iter()
                .filter(|edge| edge.props.get("fact_id") == Some(&fact_id))
                .map(|edge| GraphMutation::DeleteEdge {
                    from: edge.from,
                    label: edge.label,
                    to: edge.to,
                }),
        );
        self.run(self.graph.apply_mutations(&mutations))?;
        Ok(true)
    }

    fn link(&self, from: &str, rel: &str, to: &str, record: &MemoryId) -> Result<(), StoreError> {
        let assertion_id = relation_node_id(from, rel, to, record);
        let mut assertion_props: BTreeMap<String, Value> = BTreeMap::new();
        assertion_props.insert("from".into(), Value::String(from.to_string()));
        assertion_props.insert("rel".into(), Value::String(rel.to_string()));
        assertion_props.insert("to".into(), Value::String(to.to_string()));
        assertion_props.insert("fact_id".into(), Value::String(record.as_str().to_string()));
        let mut mutations = Vec::with_capacity(5);
        for name in [from, to] {
            let mut props: BTreeMap<String, Value> = BTreeMap::new();
            props.insert("name".into(), Value::String(name.to_string()));
            mutations.push(GraphMutation::UpsertNode(Node::new(
                ENTITY_LABEL,
                entity_node_id(name),
                props,
            )));
        }
        mutations.push(GraphMutation::UpsertNode(Node::new(
            RELATION_LABEL,
            assertion_id.clone(),
            assertion_props,
        )));
        mutations.push(GraphMutation::UpsertEdge(Edge::new(
            RELATES,
            entity_node_id(from),
            assertion_id.clone(),
            BTreeMap::new(),
        )));
        mutations.push(GraphMutation::UpsertEdge(Edge::new(
            RELATES,
            assertion_id,
            entity_node_id(to),
            BTreeMap::new(),
        )));
        self.run(self.graph.apply_mutations(&mutations))
    }

    fn neighborhood(&self, entity: &str, hops: u8) -> Result<Vec<MemoryId>, StoreError> {
        let mut out: Vec<MemoryId> = Vec::new();
        for entity_node in self.reachable_entities(entity, hops)? {
            // Records that mention this entity: one In step over MENTIONS.
            let mentions = self.run(self.graph.traverse(Traversal {
                start: Start::Node(entity_node),
                steps: vec![Step {
                    direction: Direction::In,
                    edge: Some(MENTIONS.into()),
                    node: Some(RECORD_LABEL.into()),
                }],
                limit: None,
            }))?;
            for node in mentions {
                if let Some(id) = record_id_from_node(&node.id)
                    && !out.contains(&id)
                {
                    out.push(id);
                }
            }
        }
        Ok(out)
    }
}

/// The sync→async bridge: a dedicated current-thread runtime, safe to call
/// from inside or outside another tokio runtime.
struct Bridge {
    rt: Option<tokio::runtime::Runtime>,
}

impl Bridge {
    fn new() -> Self {
        Self {
            rt: Some(
                tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .expect("bridge runtime builds"),
            ),
        }
    }

    fn run<T: Send>(&self, fut: impl Future<Output = T> + Send) -> T {
        let rt = self.rt.as_ref().expect("bridge runtime is available");
        if tokio::runtime::Handle::try_current().is_ok() {
            // Already inside a runtime: block_on here would panic. Drive the
            // bridge runtime from a scoped thread instead.
            std::thread::scope(|scope| {
                scope
                    .spawn(|| rt.block_on(fut))
                    .join()
                    .expect("bridge thread completes")
            })
        } else {
            rt.block_on(fut)
        }
    }
}

impl Drop for Bridge {
    fn drop(&mut self) {
        let Some(rt) = self.rt.take() else {
            return;
        };
        if tokio::runtime::Handle::try_current().is_ok() {
            // Dropping a runtime may block while its workers shut down, which
            // Tokio rejects inside an async context. Finish shutdown on a
            // plain thread so a TursoMemoryStore can be owned directly by an
            // async service without special drop choreography.
            std::thread::spawn(move || drop(rt))
                .join()
                .expect("bridge runtime shutdown completes");
        } else {
            drop(rt);
        }
    }
}

fn record_node_id(id: &MemoryId) -> NodeId {
    NodeId::from(format!("rec:{}", id.as_str()).as_str())
}

fn record_id_from_node(node: &NodeId) -> Option<MemoryId> {
    node.as_str()
        .strip_prefix("rec:")
        .map(MemoryId::from_string)
}

fn entity_node_id(name: &str) -> NodeId {
    NodeId::from(format!("ent:{name}").as_str())
}

fn relation_node_id(from: &str, relation: &str, to: &str, record: &MemoryId) -> NodeId {
    let mut digest = Sha256::new();
    for value in [from, relation, to, record.as_str()] {
        // A fixed-width prefix keeps ids stable across 32- and 64-bit hosts.
        let length = u64::try_from(value.len()).expect("relationship component length fits u64");
        digest.update(length.to_le_bytes());
        digest.update(value.as_bytes());
    }
    NodeId::new(format!("rel:{:x}", digest.finalize()))
}

fn encode_record(record: &StoredRecord) -> Result<Node, StoreError> {
    let json = serde_json::to_value(record)
        .map_err(|err| StoreError::Backend(format!("record serialization failed: {err}")))?;
    let mut props: BTreeMap<String, Value> = BTreeMap::new();
    props.insert("record".into(), Value::Json(json));
    props.insert("space".into(), Value::String(record.space_id.clone()));
    Ok(Node::new(RECORD_LABEL, record_node_id(&record.id), props))
}

fn decode_record(node: &Node) -> Result<StoredRecord, StoreError> {
    match node.props.get("record") {
        Some(Value::Json(json)) => serde_json::from_value(json.clone())
            .map_err(|err| StoreError::Backend(format!("record deserialization failed: {err}"))),
        _ => Err(StoreError::Backend(format!(
            "node {} has no record payload",
            node.id.as_str()
        ))),
    }
}

pub mod analytics;
pub mod cognition;
#[cfg(feature = "turso")]
pub mod turso;
pub mod vector;
#[cfg(feature = "turso")]
pub use turso::TursoMemoryStore;
pub use vector::{Embedder, VectorIndex};

#[cfg(test)]
mod tests;
